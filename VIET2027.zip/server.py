from flask import Flask, request, jsonify
from multiprocessing import Process
from queue import Queue
import threading, time, os
from urllib.parse import urlparse

app = Flask(__name__)

# Hàng chờ chứa các job
task_queue = Queue()
active_jobs = []            # Danh sách job đang chạy [(url, views), ...]
MAX_CONCURRENT = 1          # ✅ Giới hạn tối đa 2 job chạy song song
lock = threading.Lock()


# ====== HÀM CHẠY TOOL CHÍNH (ĐÃ FIX) ======
def run_tool(video_url, target_views):
    # Đảm bảo import start từ utils
    from utils import start
    from multiprocessing import Manager, Lock

    parsed = urlparse(video_url)
    parts = parsed.path.split('/')
    if len(parts) < 4:
        print("❌ URL không hợp lệ!")
        return

    video_user = parts[1]
    video_id = parts[3]

    # Cấu hình cơ bản
    base_process_count = 6
    base_workers = 300
    base_semaphore = 800

    manager = Manager()
    shared_state = manager.Namespace()
    lock_local = Lock()

    # --- KHỞI TẠO ĐẦY ĐỦ CÁC BIẾN CHO SHARED_STATE (QUAN TRỌNG) ---
    shared_state.success_count = 0
    shared_state.mode = "random"
    shared_state.fixed_device_id = None
    shared_state.fixed_iid = None
    shared_state.fail_count = 0
    
    # Các biến liên quan đến ký hiệu (Signer)
    shared_state.cached_gorgon = None
    shared_state.cached_ladon = None
    shared_state.cached_argus = None
    shared_state.cached_unix_timestamp = 0
    shared_state.cached_params_str = ""
    
    # Các biến liên quan đến API Endpoint
    shared_state.fixed_endpoint = None
    shared_state.endpoint_fail_count = 0
    shared_state.endpoint_success_count = 0
    shared_state.endpoint_total_requests = 0
    shared_state.endpoint_lock_time = 0
    
    # Các biến liên quan đến TURBO MODE (Fix lỗi AttributeError)
    shared_state.turbo_mode = False
    shared_state.base_workers = base_workers
    shared_state.base_semaphore = base_semaphore
    shared_state.base_processes = base_process_count
    shared_state.turbo_workers = base_workers * 4
    shared_state.turbo_semaphore = base_semaphore * 5
    shared_state.turbo_processes = base_process_count * 3
    shared_state.turbo_activated_time = 0
    # -------------------------------------------------------

    processes = []
    stop_flag = threading.Event()

    def monitor_views():
        last_count = 0
        while not stop_flag.is_set():
            time.sleep(2)
            current_count = shared_state.success_count
            
            # Log tiến độ ra console của Flask
            if current_count > last_count:
                print(f"[📊 Progress] {video_id}: {current_count}/{target_views}")
                last_count = current_count

            if current_count >= target_views:
                print(f"\n[🏁] {video_id} đã đạt {target_views} view — dừng tiến trình.")
                for p in processes:
                    if p.is_alive():
                        p.terminate()
                stop_flag.set()
                break

    threading.Thread(target=monitor_views, daemon=True).start()

    # Khởi chạy các tiến trình
    for _ in range(base_process_count):
        p = Process(target=start, args=(video_id, video_user, shared_state, lock_local))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

    print(f"[✅] Hoàn tất video: {video_id}")

# ====== WORKER XỬ LÝ NHIỀU JOB SONG SONG ======
def worker_loop(worker_id):
    while True:
        url, views = task_queue.get(block=True)

        with lock:
            active_jobs.append((url, views))
        print(f"\n[▶️ Worker-{worker_id}] Bắt đầu chạy link: {url} ({views} view)\n")

        try:
            run_tool(url, views)
        except Exception as e:
            print(f"[❌ Worker-{worker_id}] Lỗi khi chạy link {url}: {e}")
        finally:
            with lock:
                active_jobs.remove((url, views))
            task_queue.task_done()
            print(f"[➡️ Worker-{worker_id}] Hoàn tất. Kiểm tra hàng chờ...\n")


# ====== QUẢN LÝ WORKER ======
def worker_manager():
    # Luôn có 2 worker hoạt động song song
    for i in range(MAX_CONCURRENT):
        threading.Thread(target=worker_loop, args=(i+1,), daemon=True).start()


# Khởi động worker ngay khi server chạy
worker_manager()


# ====== API /run ======
@app.route("/run", methods=["POST"])
def run_task():
    data = request.get_json()
    if not data or "url" not in data or "views" not in data:
        return jsonify({"error": "Thiếu tham số url hoặc views"}), 400

    url = data["url"]
    target_views = int(data["views"])

    with lock:
        task_queue.put((url, target_views))
        position = task_queue.qsize()
        running = len(active_jobs)

    if running < MAX_CONCURRENT and position <= MAX_CONCURRENT:
        status = "started"
    else:
        status = "queued"

    return jsonify({
        "status": status,
        "message": f"Đã nhận yêu cầu. Vị trí trong hàng chờ: {position}",
        "url": url,
        "views": target_views
    })


@app.route("/status", methods=["GET"])
def get_status():
    with lock:
        running_jobs = list(active_jobs)
        queued = task_queue.qsize()

    return jsonify({
        "status": "running" if running_jobs else "idle",
        "running": running_jobs,
        "queue_length": queued
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
